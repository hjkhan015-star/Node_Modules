# Changelog

## 1.0.0
- **accycle, absesc, awd, airfilter 1.1.0**: replaced by the user's updated pages (moved into the split `html + js` shape, paths/imports adjusted, no logic edits).
- **differential 1.1.0** (Phase 2): Steering is a bipolar axis (no dial); every number is a Monitor row (new: turn radius, torque L / R); tokens-only CSS; dead gear-generator code removed, dual-tyre gap wired in; physics in `shared/model-drivetrain.js` with unit tests (`tests/mod-differential.test.mjs`).
- Exhaust system, lubrication, wiring: hard-coded inline colours replaced by tokens (new repo rule).
Restart of the version line. Lineage: continues the AutoLab 8.12.x codebase (full history in the Phase 0 archive `AutoLab3-after-phase0.zip`), restructured into `app/` + `tools/` + `tests/` + `docs/` with generated precache, import maps and header cards.
