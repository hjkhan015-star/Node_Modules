# AutoLab3 (Auto Lab v1.0.0)

Interactive 3D automotive learning lab — an installable, offline-capable PWA. Static site, no build step.

<!--counts:begin-->
**v1.0.0** — 52 modules (+ 7 sub-pages) in 18 systems and 5 domains, 12-stage roadmap.
<!--counts:end-->

## Layout
`app/` is the whole product (publish this folder) · `tools/` two dev scripts · `tests/` · `docs/`. See `docs/GUIDE.md` §1.

## Run, test
```
npm install            # once (installs jsdom for the DOM tests)
npm start              # http://localhost:8080  (service workers work on localhost)
npm run sync           # regenerate everything derived (precache, import maps, header cards, MODULE-MAP, version stamps)
npm test               # all tests; prints every failure; exit code ≠ 0 on any NEW failure
```
`npm run sync -- --check` fails when anything derived is stale (CI runs it).

## Deploy
Upload `app/` to any static host over **HTTPS** (Netlify, Cloudflare Pages, GitHub Pages, S3+CDN). `app/_headers` (Netlify / Cloudflare Pages format) sets the CSP,
nosniff, referrer and permissions policy, and no-cache on `sw.js` / `index.html`. GitHub Pages ignores `_headers`; replicate the headers on other hosts.

## Release
1. Bump `version` in `package.json` (the only place a version is typed).
2. `npm run sync && npm test`.
3. Deploy `app/`. The new service-worker cache name makes clients refresh.

## three.js
Three.js r160 currently loads from unpkg (cached by the service worker after the first visit). To self-host it:
`node tools/fetch-three.mjs` (needs internet once; or `--from <dir>` with a local `three@0.160.0` package). It writes `app/assets/`, switches every
import map to the local files, drops the CDN rule from `sw.js` and the CSP, and precaches the files.

## Docs
`docs/GUIDE.md` (how a module is built, the rules) · `docs/COMPONENTS.md` (control + Monitor reference) · `docs/MODULE-MAP.md` (generated) ·
`docs/DECISIONS.md` · `docs/PROGRESS.md` · `docs/AUDIT.md`.
